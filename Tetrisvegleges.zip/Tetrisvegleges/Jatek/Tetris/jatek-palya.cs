﻿namespace Tetris
{
    public class JatekRacs
    {
        private readonly int[,] racs;
        public int Sorok { get; } // ossz sor szama
        public int Oszlopok { get; } // ossz oszlop szama 


        // indexeli a sort meg oszlopot mert fasznak van kedve kiirni (r = row, (sor), c = column (oszlop)
        public int this[int r, int c]
        {
            get => racs[r, c];
            set => racs[r, c] = value;
        }


        // itt keszul el a grid a megadott sor es oszlop szam alapjan
        public JatekRacs(int sorok, int oszlopok)
        {
            Sorok = sorok;
            Oszlopok = oszlopok;
            racs = new int[sorok, oszlopok];
        }

        //  megnezi a cucc hogy a palyan belul van e minden normalisan
        public bool BelulVan(int r, int c)
        {
            return r >= 0 && r < Sorok && c >= 0 && c < Oszlopok; // ha minden jo akk true
        }

        // megnezi a cucc hogy a pozi ures e vagy sem megint igaz hamis
        public bool Ures(int r, int c)
        {
            return BelulVan(r, c) && racs[r, c] == 0;
        }

        // a sort is megnezi hgoy TELE van e megint igaz hamis
        public bool SorTele(int r)
        {
            for (int c = 0; c < Oszlopok; c++)
            {
                if (racs[r, c] == 0)
                {
                    return false;
                }
            }

            return true;
        }

        // itt pedig hogy URES E A SOR
        public bool SorUres(int r)
        {
            for (int c = 0; c < Oszlopok; c++)
            {
                if (racs[r, c] != 0) // itten van hogy szabad e a sor
                {
                    return false;
                }
            }

            return true;
        }

        // itt torol ki egy sort ha sikerult a szarosnak kitolteni egy sort
        private void SorTorles(int r)
        {
            for (int c = 0; c < Oszlopok; c++)
            {
                racs[r, c] = 0;
            }
        }

        // itt lemegy a sor ha toroltuk, tehat nem marad ott 
        private void SorLe(int r, int sorokSzama)
        {
            for (int c = 0; c < Oszlopok; c++)
            {
                racs[r + sorokSzama, c] = racs[r, c];
                racs[r, c] = 0;
            }
        }

        // kapsz egy pirospontot (pontot) ha sikerult a torles es a reset is
        public int TeljesSorokTorlese()
        {
            int torolt = 0;

            for (int r = Sorok - 1; r >= 0; r--)
            {
                if (SorTele(r))
                {
                    SorTorles(r);
                    torolt++;
                }
                else if (torolt > 0)
                {
                    SorLe(r, torolt);
                }
            }

            return torolt;
        }
    }
}

