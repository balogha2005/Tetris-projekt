﻿namespace Tetris
{

    // Ez a blokkok meg a csempék (tile) poziciojat hatarozza meg
    public class Pozicio
    {
        // a sor szama ami a pozíció vízszintes elhelyezeset adja meg
        public int Sor { get; set; }

        // az oszlop száma ami a pozíció függőleges elhelyezését adja meg
        public int Oszlop { get; set; }

        // megcsinálja a konstruktor
        public Pozicio(int sor, int oszlop)
        {
            Sor = sor; // A pozíció sorának erteke
            Oszlop = oszlop; // A pozíció oszlopának értéke
        }
    }
}


