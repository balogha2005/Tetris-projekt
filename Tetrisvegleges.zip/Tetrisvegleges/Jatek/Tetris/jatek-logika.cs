﻿namespace Tetris
{
    public class JatekAllapot
    {
        private Blokk aktualisBlokk;


        // Az aktualis hasznalatban lkevo blokk
        public Blokk AktualisBlokk
        {
            get => aktualisBlokk;
            private set
            {
                aktualisBlokk = value;
                aktualisBlokk.Alaphelyzet(); // A blokk visszaállítása

                for (int i = 0; i < 2; i++)
                {
                    aktualisBlokk.Mozgat(1, 0);


                    // ha bugos akkor újra probalja generalni 1-el arrebb
                    if (!BlokkIlleszkedik())
                    {
                        aktualisBlokk.Mozgat(-1, 0);
                    }
                }
            }
        }

        public JatekRacs JatekRacs { get; }
        public BlokkSor BlokkSor { get; }
        public bool JatekVege { get; private set; } // ha vége akkor true
        public int Pontszam { get; private set; } // aktuális pontszám
        public Blokk TartottBlokk { get; private set; } // tartott blokk
        public bool Tarolhato { get; private set; } // ha engedélyezve van akkor true, de ki lehet kapcsolni ezt a featuret

        public JatekAllapot()
        {
            JatekRacs = new JatekRacs(22, 10); //22 sor 10 oszlop
            BlokkSor = new BlokkSor(); // peldanyotiasitas
            AktualisBlokk = BlokkSor.GetAndUpdate();
            Tarolhato = true; // ITT LEHET KIKAPCSOLNI A BLOKK TAROLAST
        }


        // megnezzuk h illeszkedik a palyaba e a blokkocska
        private bool BlokkIlleszkedik()
        {
            foreach (Pozicio p in AktualisBlokk.CsempePoziciok())
            {
                if (!JatekRacs.Ures(p.Sor, p.Oszlop))
                {
                    return false;
                }
            }

            return true;
        }

        // A blokk tartásának funkciója, ha a blokk még nincs benne akk eltárolja a blokkot.
        public void BlokkTart()
        {
            if (!Tarolhato)
            {
                return;
            }

            if (TartottBlokk == null)
            {
                TartottBlokk = AktualisBlokk;
                AktualisBlokk = BlokkSor.GetAndUpdate();
            }
            else
            {
                Blokk tmp = AktualisBlokk;
                AktualisBlokk = TartottBlokk;
                TartottBlokk = tmp;
            }

            Tarolhato = false;
        }


        // a blokkot lehet forgatni, ez felel erte
        public void BlokkForgatBalra()
        {
            AktualisBlokk.ForgatBalra();

            if (!BlokkIlleszkedik())
            {
                AktualisBlokk.ForgatBalra();
            }
        }

        // A blokk balra mozgatása, ha nem illekeszdik bele akkor nem csinal semmit
        public void BlokkBalra()
        {
            AktualisBlokk.Mozgat(0, -1);

            if (!BlokkIlleszkedik())
            {
                AktualisBlokk.Mozgat(0, 1);
            }
        }

        // ugyanaz mint felette csak itt jobbra
        public void BlokkJobbra()
        {
            AktualisBlokk.Mozgat(0, 1);

            if (!BlokkIlleszkedik())
            {
                AktualisBlokk.Mozgat(0, -1);
            }
        }

        // ha a felso 1 v 2 sor nem ures akk vege a jateknak
        private bool JatekVegeE()
        {
            return !(JatekRacs.SorUres(0) && JatekRacs.SorUres(1));
        }

        // blokk lespawnolasa és pontszam frissitese ha egy sor sikeresen kesz
        private void BlokkElhelyez()
        {
            foreach (Pozicio p in AktualisBlokk.CsempePoziciok())
            {
                JatekRacs[p.Sor, p.Oszlop] = AktualisBlokk.Id;
            }

            Pontszam += JatekRacs.TeljesSorokTorlese();

            if (JatekVegeE())
            {
                JatekVege = true;
            }
            else
            {
                AktualisBlokk = BlokkSor.GetAndUpdate();
                Tarolhato = true;
            }
        }

        // blokk lefele mozgatasa, ha nem jo akk nem csinal semmit
        public void BlokkLe()
        {
            AktualisBlokk.Mozgat(1, 0);

            if (!BlokkIlleszkedik())
            {
                AktualisBlokk.Mozgat(-1, 0);
                BlokkElhelyez();
            }
        }

        // ha a spacet megnyomod akk egybol a legkozelebb lerakja a blokkot
        private int CsempeLedobTavolsag(Pozicio p)
        {
            int ledob = 0;

            // addig noveli ez a fasza while ameddig nincs szabad hely es sor neki
            while (JatekRacs.Ures(p.Sor + ledob + 1, p.Oszlop))
            {
                ledob++;
            }

            return ledob; // ha nincs akk beszoptad es nem csinal semmit
        }


        // ugyanaz csak itt tobb tilet vesz figyelembe
        public int BlokkLedobTavolsag()
        {
            int ledob = JatekRacs.Sorok;

            foreach (Pozicio p in AktualisBlokk.CsempePoziciok())
            {
                ledob = System.Math.Min(ledob, CsempeLedobTavolsag(p));
            }

            return ledob;
        }

        // itten lebasszt a blokkot ha jok az elozo ciklusok
        public void BlokkLedob()
        {
            AktualisBlokk.Mozgat(BlokkLedobTavolsag(), 0);
            BlokkElhelyez();
        }
    }
}

