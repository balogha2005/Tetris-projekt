﻿using System;
using System.Windows.Documents;

namespace Tetris
{
    public class BlokkSor
    {
        // a tetris blokk tipusok adattömbje
        private readonly Blokk[] blokkok = new Blokk[]
        {
            new IBlokk(),
            new JBlokk(),
            new LBlokk(),
            new OBlokk(),
            new SBlokk(),
            new TBlokk(),
            new ZBlokk()
        };

        // Blokkok random kiválasztása
        private readonly Random veletlen = new Random();

        // A következő blokk ami meg fog jelenni
        public Blokk KovetkezoBlokk { get; private set; }

        public BlokkSor()
        {
            KovetkezoBlokk = VeletlenBlokk();

        }
        // egy random blokk generálása a blokkos adattömbből
        private Blokk VeletlenBlokk()
        {
            return blokkok[veletlen.Next(blokkok.Length)];
        }

        // frissiti a blokkok aktualis allapotat
        public Blokk GetAndUpdate()
        {
            Blokk blokk = KovetkezoBlokk;

            do
            {
                // visszallitja a random által generált blokkot egy uj random blokkra
                KovetkezoBlokk = VeletlenBlokk();
            }
            while (blokk.Id == KovetkezoBlokk.Id);
            // a "felhasznált" blokk eltünik

            return blokk;
        }
    }
}
