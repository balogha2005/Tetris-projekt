﻿using System.Collections.Generic;

namespace Tetris
{
    
    public abstract class Blokk
    {
        // abstrakt cucc, minden blokk tud forogni, stb.
        protected abstract Pozicio[][] Csempek { get; }

        // kezdo tulajdonsag megadasa
        protected abstract Pozicio KezdOffset { get; }

        // itt custom id-t kap a blokk
        public abstract int Id { get; }

        // a forgatas letrehozasa (0 - 3, 4 fajta).
        private int forgatasiAllapot;
        private Pozicio offset;

        public Blokk()
        {
            offset = new Pozicio(KezdOffset.Sor, KezdOffset.Oszlop); // az offset ertek az a kezdo ertek
        }

        // a CsempePoziciok pedig megmutatja a blokk actual helyzetet
        public IEnumerable<Pozicio> CsempePoziciok() // ez a enumerable geci pedig végigjarja a tomboket szekvencialisan (fingom sincs koszi gpt)
        {
            foreach (Pozicio p in Csempek[forgatasiAllapot]) // actual poziciok
            {
                yield return new Pozicio(p.Sor + offset.Sor, p.Oszlop + offset.Oszlop);
            }
        }

        // jobbra forgatas (ki van veve)
        public void ForgatJobbra()
        {
            forgatasiAllapot = (forgatasiAllapot + 1) % Csempek.Length;
        }

        // balra forgatas (ez mukodik)
        public void ForgatBalra()
        {
            if (forgatasiAllapot == 0)
            {
                forgatasiAllapot = Csempek.Length - 1;
            }
            else
            {
                forgatasiAllapot--;  
            }
        }

        // itt elmozgatja a blokkot de ugy h figyeli h ne menjen ki a palyarol
        public void Mozgat(int sorok, int oszlopok)
        {
            offset.Sor += sorok; 
            offset.Oszlop += oszlopok; 
        }

        // blokk reset alaphelyzetbbe
        public void Alaphelyzet()
        {
            forgatasiAllapot = 0;  // visszaallitas 0-ra
            offset.Sor = KezdOffset.Sor;  // a kezdo ertekre visszaallitja
            offset.Oszlop = KezdOffset.Oszlop;  // meg a kezdo poziciora
        }
    }
}
