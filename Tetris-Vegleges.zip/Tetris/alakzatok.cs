﻿// Z ALAKÚ BLOKK
namespace Tetris
{
    public class ZBlokk : Blokk
    {
        // BLOKK AZONOSITOJA
        public override int Id => 7;

        // KEZDO POZICIOJA A BLOKKNAK
        protected override Pozicio KezdOffset => new(0, 3);

        // BLOKK KINÉZETE (A TEXTURAK/KEPEK ELHELYEZESE)
        protected override Pozicio[][] Csempek => new Pozicio[][] {
            new Pozicio[] {new(0,0), new(0,1), new(1,1), new(1,2)},
            new Pozicio[] {new(0,2), new(1,1), new(1,2), new(2,1)},
            new Pozicio[] {new(1,0), new(1,1), new(2,1), new(2,2)},
            new Pozicio[] {new(0,1), new(1,0), new(1,1), new(2,0)}
        };
    }
}

// T ALAKÚ BLOKK
namespace Tetris
{
    public class TBlokk : Blokk
    {
        // KEZDO POZICIOJA A BLOKKNAK
        public override int Id => 6;

        protected override Pozicio KezdOffset => new(0, 3);

        // BLOKK KINÉZETE (A TEXTURAK/KEPEK ELHELYEZESE)
        protected override Pozicio[][] Csempek => new Pozicio[][] {
            new Pozicio[] {new(0,1), new(1,0), new(1,1), new(1,2)},
            new Pozicio[] {new(0,1), new(1,1), new(1,2), new(2,1)},
            new Pozicio[] {new(1,0), new(1,1), new(1,2), new(2,1)},
            new Pozicio[] {new(0,1), new(1,0), new(1,1), new(2,1)}
        };
    }
}

// S ALAKÚ BLOKK
namespace Tetris
{
    public class SBlokk : Blokk
    {
        // KEZDO POZICIOJA A BLOKKNAK
        public override int Id => 5;

        protected override Pozicio KezdOffset => new(0, 3);

        // BLOKK KINÉZETE (A TEXTURAK/KEPEK ELHELYEZESE)
        protected override Pozicio[][] Csempek => new Pozicio[][] {
            new Pozicio[] { new(0,1), new(0,2), new(1,0), new(1,1) },
            new Pozicio[] { new(0,1), new(1,1), new(1,2), new(2,2) },
            new Pozicio[] { new(1,1), new(1,2), new(2,0), new(2,1) },
            new Pozicio[] { new(0,0), new(1,0), new(1,1), new(2,1) }
        };
    }
}

// O ALAKÚ BLOKK
namespace Tetris
{
    public class OBlokk : Blokk
    {
        private readonly Pozicio[][] csempek = new Pozicio[][]
        {
            new Pozicio[] { new(0,0), new(0,1), new(1,0), new(1,1) }
        };

        // KEZDO POZICIOJA A BLOKKNAK
        public override int Id => 4;

        // BLOKK KINÉZETE (A TEXTURAK/KEPEK ELHELYEZESE)
        protected override Pozicio KezdOffset => new Pozicio(0, 4);
        protected override Pozicio[][] Csempek => csempek;
    }
}

// L ALAKÚ BLOKK
namespace Tetris
{
    public class LBlokk : Blokk
    {
        // KEZDO POZICIOJA A BLOKKNAK
        public override int Id => 3;

        protected override Pozicio KezdOffset => new(0, 3);

        // BLOKK KINÉZETE (A TEXTURAK/KEPEK ELHELYEZESE)
        protected override Pozicio[][] Csempek => new Pozicio[][] {
            new Pozicio[] {new(0,2), new(1,0), new(1,1), new(1,2)},
            new Pozicio[] {new(0,1), new(1,1), new(2,1), new(2,2)},
            new Pozicio[] {new(1,0), new(1,1), new(1,2), new(2,0)},
            new Pozicio[] {new(0,0), new(0,1), new(1,1), new(2,1)}
        };
    }
}

// J ALAKÚ BLOKK
namespace Tetris
{
    public class JBlokk : Blokk
    {
        // KEZDO POZICIOJA A BLOKKNAK
        public override int Id => 2;

        protected override Pozicio KezdOffset => new(0, 3);

        // BLOKK KINÉZETE (A TEXTURAK/KEPEK ELHELYEZESE)
        protected override Pozicio[][] Csempek => new Pozicio[][] {
            new Pozicio[] {new(0, 0), new(1, 0), new(1, 1), new(1, 2)},
            new Pozicio[] {new(0, 1), new(0, 2), new(1, 1), new(2, 1)},
            new Pozicio[] {new(1, 0), new(1, 1), new(1, 2), new(2, 2)},
            new Pozicio[] {new(0, 1), new(1, 1), new(2, 1), new(2, 0)}
        };
    }
}

// I ALAKÚ BLOKK
namespace Tetris
{
    public class IBlokk : Blokk
    {
        private readonly Pozicio[][] csempek = new Pozicio[][]
        {
            // BLOKK KINÉZETE (A TEXTURAK/KEPEK ELHELYEZESE)
            new Pozicio[] { new(1,0), new(1,1), new(1,2), new(1,3) },
            new Pozicio[] { new(0,2), new(1,2), new(2,2), new(3,2) },
            new Pozicio[] { new(2,0), new(2,1), new(2,2), new(2,3) },
            new Pozicio[] { new(0,1), new(1,1), new(2,1), new(3,1) }
        };

        // KEZDO POZICIOJA A BLOKKNAK
        public override int Id => 1;
        protected override Pozicio KezdOffset => new Pozicio(-1, 3);
        protected override Pozicio[][] Csempek => csempek;
    }
}







