﻿namespace Tetris
{
    public class Pozicio
    {
        public int Sor { get; set; }
        public int Oszlop { get; set; }

        public Pozicio(int sor, int oszlop)
        {
            Sor = sor;
            Oszlop = oszlop;
        }
    }
}


