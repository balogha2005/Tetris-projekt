﻿using System.Collections.Generic;

namespace Tetris
{
    public abstract class Blokk
    {
        protected abstract Pozicio[][] Csempek { get; }
        protected abstract Pozicio KezdOffset { get; }
        public abstract int Id { get; }

        private int forgatasiAllapot;
        private Pozicio offset;

        public Blokk()
        {
            offset = new Pozicio(KezdOffset.Sor, KezdOffset.Oszlop);
        }

        public IEnumerable<Pozicio> CsempePoziciok()
        {
            foreach (Pozicio p in Csempek[forgatasiAllapot])
            {
                yield return new Pozicio(p.Sor + offset.Sor, p.Oszlop + offset.Oszlop);
            }
        }

        public void ForgatJobbra()
        {
            forgatasiAllapot = (forgatasiAllapot + 1) % Csempek.Length;
        }

        public void ForgatBalra()
        {
            if (forgatasiAllapot == 0)
            {
                forgatasiAllapot = Csempek.Length - 1;
            }
            else
            {
                forgatasiAllapot--;
            }
        }

        public void Mozgat(int sorok, int oszlopok)
        {
            offset.Sor += sorok;
            offset.Oszlop += oszlopok;
        }

        public void Alaphelyzet()
        {
            forgatasiAllapot = 0;
            offset.Sor = KezdOffset.Sor;
            offset.Oszlop = KezdOffset.Oszlop;
        }
    }
}
