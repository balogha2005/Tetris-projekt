﻿namespace Tetris
{
    public class JatekRacs
    {
        private readonly int[,] racs;
        public int Sorok { get; }
        public int Oszlopok { get; }

        public int this[int r, int c]
        {
            get => racs[r, c];
            set => racs[r, c] = value;
        }

        public JatekRacs(int sorok, int oszlopok)
        {
            Sorok = sorok;
            Oszlopok = oszlopok;
            racs = new int[sorok, oszlopok];
        }

        public bool BelulVan(int r, int c)
        {
            return r >= 0 && r < Sorok && c >= 0 && c < Oszlopok;
        }

        public bool Ures(int r, int c)
        {
            return BelulVan(r, c) && racs[r, c] == 0;
        }

        public bool SorTele(int r)
        {
            for (int c = 0; c < Oszlopok; c++)
            {
                if (racs[r, c] == 0)
                {
                    return false;
                }
            }

            return true;
        }

        public bool SorUres(int r)
        {
            for (int c = 0; c < Oszlopok; c++)
            {
                if (racs[r, c] != 0)
                {
                    return false;
                }
            }

            return true;
        }

        private void SorTorles(int r)
        {
            for (int c = 0; c < Oszlopok; c++)
            {
                racs[r, c] = 0;
            }
        }

        private void SorLe(int r, int sorokSzama)
        {
            for (int c = 0; c < Oszlopok; c++)
            {
                racs[r + sorokSzama, c] = racs[r, c];
                racs[r, c] = 0;
            }
        }

        public int TeljesSorokTorlese()
        {
            int torolt = 0;

            for (int r = Sorok - 1; r >= 0; r--)
            {
                if (SorTele(r))
                {
                    SorTorles(r);
                    torolt++;
                }
                else if (torolt > 0)
                {
                    SorLe(r, torolt);
                }
            }

            return torolt;
        }
    }
}

