﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Tetris
{
    /// tetris játék fő file

    public partial class MainWindow : Window
    {

        // csempék / blokkok textúrái

        private readonly ImageSource[] csempeKepek = new ImageSource[]
        {
            new BitmapImage(new Uri("texturak/ures-textura.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/cian-textura.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/kek-textura.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/narancs-textura.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/sarga-textura.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/zold-textura.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/rozsaszin-textura.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/piros-textura.png", UriKind.Relative))
        };

        // alakzatok textúriá

        private readonly ImageSource[] blokkKepek = new ImageSource[]
        {
            new BitmapImage(new Uri("texturak/ures-blokk.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/blokk-I.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/blokk-J.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/blokk-L.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/blokk-O.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/blokk-S.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/blokk-T.png", UriKind.Relative)),
            new BitmapImage(new Uri("texturak/blokk-Z.png", UriKind.Relative))
        };


       // textúrák átnézése

        private readonly Image[,] kepEllenorzes;
        private readonly int maxKeses = 1000;
        private readonly int minKeses = 75;
        private readonly int kesesCsokkentes = 25;

        private JatekAllapot jatekAllapot;
        private DateTime jatekKezdete;
        private const string pontszamokeleres = "pontszamok.json";


        // maga a játékfelület 
        public MainWindow()
        {
            InitializeComponent();
            kepEllenorzes = JatekVaszonBeallitasa(new JatekRacs(22, 10));
            BetoltottPontszamok();
        }

        private Image[,] JatekVaszonBeallitasa(JatekRacs racs)
        {
            Image[,] kepEllenorzes = new Image[racs.Sorok, racs.Oszlopok];
            int cellaMeret = 25;

            for (int r = 0; r < racs.Sorok; r++)
            {
                for (int c = 0; c < racs.Oszlopok; c++)
                {
                    Image kepEllenorzesElem = new Image
                    {
                        Width = cellaMeret,
                        Height = cellaMeret
                    };


         // berakja a képeket blokkokat és megnézi, hogy jók e

                    Canvas.SetTop(kepEllenorzesElem, (r - 2) * cellaMeret + 10);
                    Canvas.SetLeft(kepEllenorzesElem, c * cellaMeret);
                    JatekVaszon.Children.Add(kepEllenorzesElem);
                    kepEllenorzes[r, c] = kepEllenorzesElem;
                }
            }

            return kepEllenorzes;
        }

        // rács generálása

        private void RacsRajzolas(JatekRacs racs)
        {
            for (int r = 0; r < racs.Sorok; r++)
            {
                for (int c = 0; c < racs.Oszlopok; c++)
                {
                    int id = racs[r, c];
                    kepEllenorzes[r, c].Opacity = 1;
                    kepEllenorzes[r, c].Source = csempeKepek[id];
                }
            }
        }

        // Blokkok generálása
        private void BlokkRajzolas(Blokk blokk)
        {
            foreach (Pozicio p in blokk.CsempePoziciok())
            {
                kepEllenorzes[p.Sor, p.Oszlop].Opacity = 1;
                kepEllenorzes[p.Sor, p.Oszlop].Source = csempeKepek[blokk.Id];
            }
        }

        // új blokk generálása random modon
        private void KovetkezoBlokkRajzolas(BlokkSor blokkSor)
        {
            Blokk kovetkezo = blokkSor.KovetkezoBlokk;
            KovetkezoKep.Source = blokkKepek[kovetkezo.Id];
        }

        // a megtartott blokk generálása
        private void TartottBlokkRajzolas(Blokk tartottBlokk)
        {
            if (tartottBlokk == null)
            {
                TartottKep.Source = blokkKepek[0];
            }
            else
            {
                TartottKep.Source = blokkKepek[tartottBlokk.Id];
            }
        }

        // pálya generálása
        private void Rajzolas(JatekAllapot jatekAllapot)
        {
            RacsRajzolas(jatekAllapot.JatekRacs);
            BlokkRajzolas(jatekAllapot.AktualisBlokk);
            KovetkezoBlokkRajzolas(jatekAllapot.BlokkSor);
            TartottBlokkRajzolas(jatekAllapot.TartottBlokk);
            PontszamSzoveg.Text = $"Pontszám: {jatekAllapot.Pontszam}";
        }

        // játék
        private async Task JatekCiklus()
        {
            Rajzolas(jatekAllapot);

            while (!jatekAllapot.JatekVege)
            {
                int keses = Math.Max(minKeses, maxKeses - (jatekAllapot.Pontszam * kesesCsokkentes));
                await Task.Delay(keses);
                jatekAllapot.BlokkLe();
                Rajzolas(jatekAllapot);
                FrissitJatekIdo();
            }

            JatekVegeMenu.Visibility = Visibility.Visible;
            VegsoPontszamSzoveg.Text = $"Pontszám: {jatekAllapot.Pontszam}";
            VegsoJatekIdoSzoveg.Text = $"Játékidő: {DateTime.Now - jatekKezdete:mm\\:ss}";
            MentesPontszam(jatekAllapot.Pontszam);
        }
        // Játékidő frissítése
        private void FrissitJatekIdo()
        {
            var jatekIdo = DateTime.Now - jatekKezdete;
            JatekIdoSzoveg.Text = $"Játékidő: {jatekIdo:mm\\:ss}";
        }

        // gombok lenyomásának érzékelése
        private void Ablak_BillentyuLenyomas(object sender, KeyEventArgs e)
        {
            if (jatekAllapot == null || jatekAllapot.JatekVege)
            {
                return;
            }

            switch (e.Key)
            {
                case Key.Left:
                    jatekAllapot.BlokkBalra();
                    break;
                case Key.Right:
                    jatekAllapot.BlokkJobbra();
                    break;
                case Key.Down:
                    jatekAllapot.BlokkLe();
                    break;
                case Key.Up:
                    jatekAllapot.BlokkForgatBalra();
                    break;
                case Key.C:
                    jatekAllapot.BlokkTart();
                    break;
                case Key.Space:
                    jatekAllapot.BlokkLedob();
                    break;
                default:
                    return;
            }

            Rajzolas(jatekAllapot);
        }
        
        // újjáték gomb
        private async void UjraJatszas_Click(object sender, RoutedEventArgs e)
        {
            jatekAllapot = new JatekAllapot();
            JatekVegeMenu.Visibility = Visibility.Hidden;
            jatekKezdete = DateTime.Now;
            await JatekCiklus();
        }

        // Vissza a menübe gomb
        private void VisszaAMenube_Click(object sender, RoutedEventArgs e)
        {
            JatekVegeMenu.Visibility = Visibility.Hidden;
            FoMenu.Visibility = Visibility.Visible;
        }

        // Játék indítása gomb eseménykezelő
        private async void JatekInditas_Click(object sender, RoutedEventArgs e)
        {
            FoMenu.Visibility = Visibility.Hidden;
            JatekVegeMenu.Visibility = Visibility.Hidden;
            jatekAllapot = new JatekAllapot();
            jatekKezdete = DateTime.Now;
            await JatekCiklus();
        }

        // Kilépés gomb
        private void Kilepes_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        // Pontszám mentése
        private void MentesPontszam(int pontszam)
        {
            List<PontszamAdat> pontszamok = BetoltottPontszamok();
            var jatekVege = DateTime.Now;
            var jatekIdo = jatekVege - jatekKezdete;

            pontszamok.Add(new PontszamAdat
            {
                Pontszam = pontszam,
                DatumIdopont = jatekVege,
                JatekIdo = jatekIdo
            });

            pontszamok.Sort((a, b) => b.Pontszam.CompareTo(a.Pontszam)); 

            string json = JsonSerializer.Serialize(pontszamok);
            File.WriteAllText(pontszamokeleres, json);

            FrissitPontszamLista(pontszamok);
        }

        // Pontszámok betöltése

        private List<PontszamAdat> BetoltottPontszamok()
        {
            if (File.Exists(pontszamokeleres))
            {
                string json = File.ReadAllText(pontszamokeleres);
                try
                {
                    List<PontszamAdat> pontszamok = JsonSerializer.Deserialize<List<PontszamAdat>>(json);
                    FrissitPontszamLista(pontszamok);
                    return pontszamok;
                }
                catch (JsonException)
                {
                    return new List<PontszamAdat>();
                }
            }
            else
            {
                return new List<PontszamAdat>();
            }
        }

        // Pontszám lista frissítése
        private void FrissitPontszamLista(List<PontszamAdat> pontszamok)
        {
            PontszamLista.Items.Clear();
            foreach (var pontszamAdat in pontszamok)
            {
                PontszamLista.Items.Add($"{pontszamAdat.DatumIdopont:yyyy-MM-dd HH:mm} - Játékidő: {pontszamAdat.JatekIdo:mm\\:ss} - Pontszám: {pontszamAdat.Pontszam}");
            }
        }
    }

    // Pontszám adattömb kezelés
    public class PontszamAdat
    {
        public int Pontszam { get; set; }
        public DateTime DatumIdopont { get; set; }
        public TimeSpan JatekIdo { get; set; }
    }
}


