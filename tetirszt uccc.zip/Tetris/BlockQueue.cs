﻿using System;
using System.Windows.Documents;

namespace Tetris
{
    public class BlokkSor
    {
        private readonly Blokk[] blokkok = new Blokk[]
        {
            new IBlokk(),
            new JBlokk(),
            new LBlokk(),
            new OBlokk(),
            new SBlokk(),
            new TBlokk(),
            new ZBlokk()
        };

        private readonly Random veletlen = new Random();

        public Blokk KovetkezoBlokk { get; private set; }

        public BlokkSor()
        {
            KovetkezoBlokk = VeletlenBlokk();
        }

        private Blokk VeletlenBlokk()
        {
            return blokkok[veletlen.Next(blokkok.Length)];
        }

        public Blokk GetAndUpdate()
        {
            Blokk blokk = KovetkezoBlokk;

            do
            {
                KovetkezoBlokk = VeletlenBlokk();
            }
            while (blokk.Id == KovetkezoBlokk.Id);

            return blokk;
        }
    }
}
