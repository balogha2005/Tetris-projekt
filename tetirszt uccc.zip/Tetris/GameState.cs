﻿namespace Tetris
{
    public class JatekAllapot
    {
        private Blokk aktualisBlokk;

        public Blokk AktualisBlokk
        {
            get => aktualisBlokk;
            private set
            {
                aktualisBlokk = value;
                aktualisBlokk.Alaphelyzet();

                for (int i = 0; i < 2; i++)
                {
                    aktualisBlokk.Mozgat(1, 0);

                    if (!BlokkIlleszkedik())
                    {
                        aktualisBlokk.Mozgat(-1, 0);
                    }
                }
            }
        }

        public JatekRacs JatekRacs { get; }
        public BlokkSor BlokkSor { get; }
        public bool JatekVege { get; private set; }
        public int Pontszam { get; private set; }
        public Blokk TartottBlokk { get; private set; }
        public bool Tarolhato { get; private set; }

        public JatekAllapot()
        {
            JatekRacs = new JatekRacs(22, 10);
            BlokkSor = new BlokkSor();
            AktualisBlokk = BlokkSor.GetAndUpdate();
            Tarolhato = true;
        }

        private bool BlokkIlleszkedik()
        {
            foreach (Pozicio p in AktualisBlokk.CsempePoziciok())
            {
                if (!JatekRacs.Ures(p.Sor, p.Oszlop))
                {
                    return false;
                }
            }

            return true;
        }

        public void BlokkTart()
        {
            if (!Tarolhato)
            {
                return;
            }

            if (TartottBlokk == null)
            {
                TartottBlokk = AktualisBlokk;
                AktualisBlokk = BlokkSor.GetAndUpdate();
            }
            else
            {
                Blokk tmp = AktualisBlokk;
                AktualisBlokk = TartottBlokk;
                TartottBlokk = tmp;
            }

            Tarolhato = false;
        }

        public void BlokkForgatJobbra()
        {
            AktualisBlokk.ForgatJobbra();

            if (!BlokkIlleszkedik())
            {
                AktualisBlokk.ForgatBalra();
            }
        }

        public void BlokkForgatBalra()
        {
            AktualisBlokk.ForgatBalra();

            if (!BlokkIlleszkedik())
            {
                AktualisBlokk.ForgatJobbra();
            }
        }

        public void BlokkBalra()
        {
            AktualisBlokk.Mozgat(0, -1);

            if (!BlokkIlleszkedik())
            {
                AktualisBlokk.Mozgat(0, 1);
            }
        }

        public void BlokkJobbra()
        {
            AktualisBlokk.Mozgat(0, 1);

            if (!BlokkIlleszkedik())
            {
                AktualisBlokk.Mozgat(0, -1);
            }
        }

        private bool JatekVegeE()
        {
            return !(JatekRacs.SorUres(0) && JatekRacs.SorUres(1));
        }

        private void BlokkElhelyez()
        {
            foreach (Pozicio p in AktualisBlokk.CsempePoziciok())
            {
                JatekRacs[p.Sor, p.Oszlop] = AktualisBlokk.Id;
            }

            Pontszam += JatekRacs.TeljesSorokTorlese();

            if (JatekVegeE())
            {
                JatekVege = true;
            }
            else
            {
                AktualisBlokk = BlokkSor.GetAndUpdate();
                Tarolhato = true;
            }
        }

        public void BlokkLe()
        {
            AktualisBlokk.Mozgat(1, 0);

            if (!BlokkIlleszkedik())
            {
                AktualisBlokk.Mozgat(-1, 0);
                BlokkElhelyez();
            }
        }

        private int CsempeLedobTavolsag(Pozicio p)
        {
            int ledob = 0;

            while (JatekRacs.Ures(p.Sor + ledob + 1, p.Oszlop))
            {
                ledob++;
            }

            return ledob;
        }

        public int BlokkLedobTavolsag()
        {
            int ledob = JatekRacs.Sorok;

            foreach (Pozicio p in AktualisBlokk.CsempePoziciok())
            {
                ledob = System.Math.Min(ledob, CsempeLedobTavolsag(p));
            }

            return ledob;
        }

        public void BlokkLedob()
        {
            AktualisBlokk.Mozgat(BlokkLedobTavolsag(), 0);
            BlokkElhelyez();
        }
    }
}

