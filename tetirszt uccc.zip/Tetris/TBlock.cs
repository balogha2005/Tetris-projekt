﻿namespace Tetris
{
    public class TBlokk : Blokk
    {
        public override int Id => 6;

        protected override Pozicio KezdOffset => new(0, 3);

        protected override Pozicio[][] Csempek => new Pozicio[][] {
            new Pozicio[] {new(0,1), new(1,0), new(1,1), new(1,2)},
            new Pozicio[] {new(0,1), new(1,1), new(1,2), new(2,1)},
            new Pozicio[] {new(1,0), new(1,1), new(1,2), new(2,1)},
            new Pozicio[] {new(0,1), new(1,0), new(1,1), new(2,1)}
        };
    }
}




