﻿namespace Tetris
{
    public class LBlokk : Blokk
    {
        public override int Id => 3;

        protected override Pozicio KezdOffset => new(0, 3);

        protected override Pozicio[][] Csempek => new Pozicio[][] {
            new Pozicio[] {new(0,2), new(1,0), new(1,1), new(1,2)},
            new Pozicio[] {new(0,1), new(1,1), new(2,1), new(2,2)},
            new Pozicio[] {new(1,0), new(1,1), new(1,2), new(2,0)},
            new Pozicio[] {new(0,0), new(0,1), new(1,1), new(2,1)}
        };
    }
}


