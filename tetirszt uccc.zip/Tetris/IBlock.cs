﻿namespace Tetris
{
    public class IBlokk : Blokk
    {
        private readonly Pozicio[][] csempek = new Pozicio[][]
        {
            new Pozicio[] { new(1,0), new(1,1), new(1,2), new(1,3) },
            new Pozicio[] { new(0,2), new(1,2), new(2,2), new(3,2) },
            new Pozicio[] { new(2,0), new(2,1), new(2,2), new(2,3) },
            new Pozicio[] { new(0,1), new(1,1), new(2,1), new(3,1) }
        };

        public override int Id => 1;
        protected override Pozicio KezdOffset => new Pozicio(-1, 3);
        protected override Pozicio[][] Csempek => csempek;
    }
}

