## Tetris Source Code
This folder contains the source code for the OttoBotCode Tetris Tutorial:  
https://www.youtube.com/watch?v=jcUctrLC-7M

Feel free to use this code in your own project, but don't distribute it to other people.  
If you have any issues, contact me on Patreon:  
https://www.patreon.com/OttoBotCode