﻿namespace Tetris
{
    public class JátékÁllapot
    {
        private Blokk currentBlock;

        public Blokk CurrentBlock
        {
            get => currentBlock;
            private set
            {
                currentBlock = value;
                currentBlock.Visszaállít();

                for (int i = 0; i < 2; i++)
                {
                    currentBlock.Mozgat(1, 0);

                    if (!BlockFits())
                    {
                        currentBlock.Mozgat(-1, 0);
                    }
                }
            }
        }

        public JátékRács JátékRács { get; }
        public BlokkSor BlokkSor { get; }
        public bool GameOver { get; private set; }
        public int Pontszám { get; private set; }
        public Blokk HeldBlock { get; private set; }
        public bool CanHold { get; private set; }

        public JátékÁllapot()
        {
            JátékRács = new JátékRács(22, 10);
            BlokkSor = new BlokkSor();
            CurrentBlock = BlokkSor.GetAndUpdate();
            CanHold = true;
        }

        private bool BlockFits()
        {
            foreach (Pozíció p in CurrentBlock.TilePositions())
            {
                if (!JátékRács.IsEmpty(p.Sor, p.Oszlop))
                {
                    return false;
                }
            }

            return true;
        }

        public void HoldBlock()
        {
            if (!CanHold)
            {
                return;
            }

            if (HeldBlock == null)
            {
                HeldBlock = CurrentBlock;
                CurrentBlock = BlokkSor.GetAndUpdate();
            }
            else
            {
                Blokk tmp = CurrentBlock;
                CurrentBlock = HeldBlock;
                HeldBlock = tmp;
            }

            CanHold = false;
        }

        public void RotateBlockCW()
        {
            CurrentBlock.RotateCW();

            if (!BlockFits())
            {
                CurrentBlock.RotateCCW();
            }
        }

        public void RotateBlockCCW()
        {
            CurrentBlock.RotateCCW();

            if (!BlockFits())
            {
                CurrentBlock.RotateCW();
            }
        }

        public void MoveBlockLeft()
        {
            CurrentBlock.Mozgat(0, -1);

            if (!BlockFits())
            {
                CurrentBlock.Mozgat(0, 1);
            }
        }

        public void MoveBlockRight()
        {
            CurrentBlock.Mozgat(0, 1);

            if (!BlockFits())
            {
                CurrentBlock.Mozgat(0, -1);
            }
        }

        private bool IsGameOver()
        {
            return !(JátékRács.IsRowEmpty(0) && JátékRács.IsRowEmpty(1));
        }

        private void PlaceBlock()
        {
            foreach (Pozíció p in CurrentBlock.TilePositions())
            {
                JátékRács[p.Sor, p.Oszlop] = CurrentBlock.Id;
            }

            Pontszám += JátékRács.ClearFullRows();

            if (IsGameOver())
            {
                GameOver = true;
            }
            else
            {
                CurrentBlock = BlokkSor.GetAndUpdate();
                CanHold = true;
            }
        }

        public void MoveBlockDown()
        {
            CurrentBlock.Mozgat(1, 0);

            if (!BlockFits())
            {
                CurrentBlock.Mozgat(-1, 0);
                PlaceBlock();
            }
        }

        private int TileDropDistance(Pozíció p)
        {
            int drop = 0;

            while (JátékRács.IsEmpty(p.Sor + drop + 1, p.Oszlop))
            {
                drop++;
            }

            return drop;
        }

        public int BlockDropDistance()
        {
            int drop = JátékRács.Rows;

            foreach (Pozíció p in CurrentBlock.TilePositions())
            {
                drop = System.Math.Min(drop, TileDropDistance(p));
            }

            return drop;
        }

        public void DropBlock()
        {
            CurrentBlock.Mozgat(BlockDropDistance(), 0);
            PlaceBlock();
        }
    }
}
