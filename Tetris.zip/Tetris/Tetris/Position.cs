﻿namespace Tetris
{
    public class Pozíció
    {
        public int Sor { get; set; }
        public int Oszlop { get; set; }

        public Pozíció(int row, int column)
        {
            Sor = row;
            Oszlop = column;
        }
    }
}
