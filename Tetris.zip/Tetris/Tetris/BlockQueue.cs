﻿using System;

namespace Tetris
{
    public class BlokkSor
    {
        private readonly Blokk[] blocks = new Blokk[]
        {
            new IBlokk(),
            new JBlokk(),
            new LBlokk(),
            new OBlokk(),
            new SBlokk(),
            new TBlokk(),
            new ZBlokk()
        };

        private readonly Random random = new Random();

        public Blokk NextBlock { get; private set; }

        public BlokkSor()
        {
            NextBlock = RandomBlock();
        }

        private Blokk RandomBlock()
        {
            return blocks[random.Next(blocks.Length)];
        }

        public Blokk GetAndUpdate()
        {
            Blokk block = NextBlock;

            do
            {
                NextBlock = RandomBlock();
            }
            while (block.Id == NextBlock.Id);

            return block;
        }
    }
}
