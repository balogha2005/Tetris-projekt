﻿using System.Collections.Generic;

namespace Tetris
{
    public abstract class Blokk
    {
        protected abstract Pozíció[][] Tiles { get; }
        protected abstract Pozíció StartOffset { get; }
        public abstract int Id { get; }

        private int rotationState;
        private Pozíció offset;

        public Blokk()
        {
            offset = new Pozíció(StartOffset.Sor, StartOffset.Oszlop);
        }

        public IEnumerable<Pozíció> TilePositions()
        {
            foreach (Pozíció p in Tiles[rotationState])
            {
                yield return new Pozíció(p.Sor + offset.Sor, p.Oszlop + offset.Oszlop);
            }
        }

        public void RotateCW()
        {
            rotationState = (rotationState + 1) % Tiles.Length;
        }

        public void RotateCCW()
        {
            if (rotationState == 0)
            {
                rotationState = Tiles.Length - 1;
            }
            else
            {
                rotationState--;
            }
        }

        public void Mozgat(int rows, int columns)
        {
            offset.Sor += rows;
            offset.Oszlop += columns;
        }

        public void Visszaállít()
        {
            rotationState = 0;
            offset.Sor = StartOffset.Sor;
            offset.Oszlop = StartOffset.Oszlop;
        }
    }
}
