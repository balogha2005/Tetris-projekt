﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Tetris
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly ImageSource[] tileImages = new ImageSource[]
        {
            new BitmapImage(new Uri("Assets/TileEmpty.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileCyan.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileBlue.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileOrange.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileYellow.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileGreen.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TilePurple.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileRed.png", UriKind.Relative))
        };

        private readonly ImageSource[] blockImages = new ImageSource[]
        {
            new BitmapImage(new Uri("Assets/Blokk-Empty.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Blokk-I.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Blokk-J.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Blokk-L.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Blokk-O.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Blokk-S.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Blokk-T.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Blokk-Z.png", UriKind.Relative))
        };

        private readonly Image[,] imageControls;
        private readonly int maxDelay = 1000;
        private readonly int minDelay = 75;
        private readonly int delayDecrease = 25;

        private JátékÁllapot gameState = new JátékÁllapot();

        public MainWindow()
        {
            InitializeComponent();
            imageControls = SetupGameCanvas(gameState.JátékRács);
        }

        private Image[,] SetupGameCanvas(JátékRács grid)
        {
            Image[,] imageControls = new Image[grid.Rows, grid.Columns];
            int cellSize = 25;

            for (int r = 0; r < grid.Rows; r++)
            {
                for (int c = 0; c < grid.Columns; c++)
                {
                    Image imageControl = new Image
                    {
                        Width = cellSize,
                        Height = cellSize
                    };

                    Canvas.SetTop(imageControl, (r - 2) * cellSize + 10);
                    Canvas.SetLeft(imageControl, c * cellSize);
                    GameCanvas.Children.Add(imageControl);
                    imageControls[r, c] = imageControl;
                }
            }

            return imageControls;
        }

        private void DrawGrid(JátékRács grid)
        {
            for (int r = 0; r < grid.Rows; r++)
            {
                for (int c = 0; c < grid.Columns; c++)
                {
                    int id = grid[r, c];
                    imageControls[r, c].Opacity = 1;
                    imageControls[r, c].Source = tileImages[id];
                }
            }
        }

        private void DrawBlock(Blokk block)
        {
            foreach (Pozíció p in block.TilePositions())
            {
                imageControls[p.Sor, p.Oszlop].Opacity = 1;
                imageControls[p.Sor, p.Oszlop].Source = tileImages[block.Id];
            }
        }

        private void DrawNextBlock(BlokkSor blockQueue)
        {
            Blokk next = blockQueue.NextBlock;
            NextImage.Source = blockImages[next.Id];
        }

        private void DrawHeldBlock(Blokk heldBlock)
        {
            if (heldBlock == null)
            {
                HoldImage.Source = blockImages[0];
            }
            else
            {
                HoldImage.Source = blockImages[heldBlock.Id];
            }
        }

        private void DrawGhostBlock(Blokk block)
        {
            int dropDistance = gameState.BlockDropDistance();

            foreach (Pozíció p in block.TilePositions())
            {
                imageControls[p.Sor + dropDistance, p.Oszlop].Opacity = 0.25;
                imageControls[p.Sor + dropDistance, p.Oszlop].Source = tileImages[block.Id];
            }
        }

        private void Draw(JátékÁllapot gameState)
        {
            DrawGrid(gameState.JátékRács);
            DrawGhostBlock(gameState.CurrentBlock);
            DrawBlock(gameState.CurrentBlock);
            DrawNextBlock(gameState.BlokkSor);
            DrawHeldBlock(gameState.HeldBlock);
            ScoreText.Text = $"Pontszám: {gameState.Pontszám}";
        }

        private async Task GameLoop()
        {
            Draw(gameState);

            while (!gameState.GameOver)
            {
                int delay = Math.Max(minDelay, maxDelay - (gameState.Pontszám * delayDecrease));
                await Task.Delay(delay);
                gameState.MoveBlockDown();
                Draw(gameState);
            }

            GameOverMenu.Visibility = Visibility.Visible;
            FinalScoreText.Text = $"Pontszám: {gameState.Pontszám}";
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (gameState.GameOver)
            {
                return;
            }

            switch (e.Key)
            {
                case Key.Left:
                    gameState.MoveBlockLeft();
                    break;
                case Key.Right:
                    gameState.MoveBlockRight();
                    break;
                case Key.Down:
                    gameState.MoveBlockDown();
                    break;
                case Key.Up:
                    gameState.RotateBlockCW();
                    break;
                case Key.Z:
                    gameState.RotateBlockCCW();
                    break;
                case Key.C:
                    gameState.HoldBlock();
                    break;
                case Key.Space:
                    gameState.DropBlock();
                    break;
                default:
                    return;
            }

            Draw(gameState);
        }

        private async void GameCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            await GameLoop();
        }

        private async void PlayAgain_Click(object sender, RoutedEventArgs e)
        {
            gameState = new JátékÁllapot();
            GameOverMenu.Visibility = Visibility.Hidden;
            await GameLoop();
        }
    }
}
